package beans;
public class ShoppingItem {
  public int productcode;
  public double price;
  public String name;
  public String description;
  public int quantity;
}