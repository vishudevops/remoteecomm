package beans;

public class Product {
  public int code;
  public String name;
  public String description;
  public double price;
}